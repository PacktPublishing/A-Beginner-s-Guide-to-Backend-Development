var name = "Jack";
var age = 23;
var shootingScore = 45.6;

var message = "Hi, my name is " + name + " and I am " + age + " years old!";

var firstName = "John";
var lastName = "JacobJingleHeimerSmith";
var dateOfBirth = "10-09-82";
var age = 23;
var profileImgUrl = 'http://coolpicks.com/johnjacob.jpg';

var loginWelcomeMessage = "Welcome, " + firstName + ". Happy " + age + "rd birthday!" ;

console.log(loginWelcomeMessage);
