var sum = 10 + 15;
var sub = 15 - 10;
var mul = 10 * 3;
var div = 10 / 3;
var mod = 10 % 3;

var msg = "10 / 3 = 3 with a remainder of " + mod;

var result = 10 * ((5 + 3) - 4);

console.log(result);
